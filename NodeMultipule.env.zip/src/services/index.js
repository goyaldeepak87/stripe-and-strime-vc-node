module.exports.authService = require('./auth.service');
module.exports.userService = require('./user.service');
module.exports.tokenService = require("./token.service")
module.exports.fileService = require("./file.service")
module.exports.guestTokenService = require("./guestToken.service")
module.exports.meetingService = require("./meeting.service")