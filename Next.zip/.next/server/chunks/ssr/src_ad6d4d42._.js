module.exports = {

"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}}),
"[project]/src/app/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$auth$2f$LoginFormModel$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/auth/LoginFormModel.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CardCompUI$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CardCompUI.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginPage$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LoginPage.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$NaveBar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/NaveBar.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lang$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lang/index.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$NaveBar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/page.js",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-evenly min-h bg-orange-200",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lang$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["animations"].map((values, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CardCompUI$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        ...values
                    }, index, false, {
                        fileName: "[project]/src/app/page.js",
                        lineNumber: 13,
                        columnNumber: 11
                    }, this) // Replace with the actual path to your JSON animation file
                )
            }, void 0, false, {
                fileName: "[project]/src/app/page.js",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            userLogin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex min-h-screen items-center justify-center bg-gradient-to-b from-[#0d1b2a] to-[#1b263b]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white shadow-lg rounded-lg flex max-w-4xl w-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$auth$2f$LoginFormModel$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/app/page.js",
                            lineNumber: 21,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.js",
                        lineNumber: 19,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.js",
                    lineNumber: 18,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.js",
                lineNumber: 17,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
}}),
"[project]/src/app/page.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/page.js [app-rsc] (ecmascript)"));
}}),
"[project]/src/lang/index.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "LoaderData": (()=>LoaderData),
    "LoginData": (()=>LoginData),
    "SignupData": (()=>SignupData),
    "animations": (()=>animations),
    "successPayment": (()=>successPayment)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation2.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation3.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation4.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Loader.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/success.json (json)");
;
;
;
;
;
;
const animations = [
    {
        id: 1,
        active: true,
        prodectId: "ReTiChat11",
        title: "Real - Time Stream Chat",
        label: "Live Chat Feature",
        text: "Engage with your audience instantly using our live stream chat feature. Perfect for creators, teachers, or hosts who want real-time interaction during any broadcast or live session.",
        price: "$5",
        leftShift: "1/2",
        topShift: "15",
        lftShiftIline: "125",
        topShiftIline: "60",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__["default"],
            width: 120,
            height: 120
        }
    },
    {
        id: 2,
        active: false,
        prodectId: "ViCaLiComments12",
        title: "Video Call & Live Comments",
        label: "Interactive Video Call",
        text: " seamless video calls with the added power of live commenting. Collaborate, teach, or connect with multiple users while engaging them through real-time feedback and chat interactions.",
        price: "$12",
        leftShift: "25",
        topShift: "15",
        topShiftIline: "61",
        lftShiftIline: "110",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__["default"],
            width: 190,
            height: 140
        }
    },
    {
        id: 3,
        active: true,
        prodectId: "ScSharCalls13",
        title: "Screen Sharing in Calls",
        label: "Screen Share Tool",
        text: "Share your screen effortlessly during video calls. Ideal for presentations, demos, remote support, or online teaching — make your sessions more interactive and visually rich.",
        price: "$18",
        leftShift: "20",
        lftShiftIline: "75",
        topShiftIline: "75",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__["default"],
            width: 226,
            height: 134
        }
    }
];
const LoginData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const successPayment = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const LoaderData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__["default"],
        width: 110,
        height: 24
    }
};
const SignupData = [
    {
        id: 1,
        icon: "https://www.svgrepo.com/show/355037/google.svg",
        label: "Google"
    },
    {
        id: 2,
        icon: "https://www.svgrepo.com/show/157818/facebook.svg",
        label: "Facebook"
    }
];
}}),
"[project]/src/utils/validationSchema.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "validateLoginForm": (()=>validateLoginForm)
});
const validateLoginForm = (values)=>{
    const errors = {};
    // Email Validation
    if (!values.email) {
        errors.email = 'Email is required';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
        errors.email = 'Invalid email address';
    }
    // Password Validation
    if (!values.password) {
        errors.password = 'Password is required';
    } else if (values.password.length < 6) {
        errors.password = 'Password must be at least 6 characters';
    }
    return errors;
};
}}),
"[project]/src/reudux/slice/authSlice.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/redux/slice/authSlice.js
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "loginUser": (()=>loginUser),
    "logout": (()=>logout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-rsc] (ecmascript)");
;
;
const loginUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('auth/loginUser', async (credentials, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].post('http://localhost:8003/v1/auth/guest-user/login', credentials); // Replace with your API endpoint
        // const response = await axios.post('/api/login', credentials); // Replace with your API endpoint
        console.log('Login response:', response.data); // Log the response for debugging
        return response.data; // Return user data if login is successful
    } catch (error) {
        return rejectWithValue(error.response?.data || 'Login failed'); // Handle errors
    }
});
const authSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'auth',
    initialState: {
        user: null,
        isAuthenticated: false,
        loading: false,
        error: null
    },
    reducers: {
        logout (state) {
            state.isAuthenticated = false;
            state.user = null;
            state.loading = false;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(loginUser.pending, (state)=>{
            state.loading = true;
            state.error = null; // Reset error on new login attempt
        }).addCase(loginUser.fulfilled, (state, action)=>{
            state.loading = false;
            state.isAuthenticated = true;
            state.user = action.payload; // Set user data upon successful login
        }).addCase(loginUser.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload; // Set error message on failure
        });
    }
});
const { logout } = authSlice.actions;
const __TURBOPACK__default__export__ = authSlice.reducer;
}}),

};

//# sourceMappingURL=src_ad6d4d42._.js.map