module.exports = {

"[project]/.next-internal/server/app/(auth)/live-calls/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=_next-internal_server_app_%28auth%29_live-calls_page_actions_8014f4cf.js.map