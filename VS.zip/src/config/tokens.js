const tokenTypes = {
  ACCESS: 'access',
  GUESTACCESS: 'guest',
  REFRESH: 'refresh',
  RESET_PASSWORD: 'resetPassword',
  VERIFY_EMAIL: 'verifyEmail',
};

module.exports = {
  tokenTypes,
};
